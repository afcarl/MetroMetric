### MetroMetric

My project to measure the performance of [**DC Nextbus**](http://www.wmata.com/rider_tools/nextbus/arrivals.cfm)

Goals:
* For a variety of bus routes, explore:
  * performance of the algorithm overall
  * dependence on route, time of day, day of week, and (maybe) weather
  * if I can identify problem buses real time

My initial goal is to collect a weeks's worth of data for 5 lines with different characteristics.


